import WeatherProjectPart3 from "./WeatherProject_Part3";
import WeatherProjectPart2 from "./WeatherProject_Part2";
import WeatherProjectPart1 from "./WeatherProject_Part1";
import WeatherProject from "./WeatherProject";

export default WeatherProject;